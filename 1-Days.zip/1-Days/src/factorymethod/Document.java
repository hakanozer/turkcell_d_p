package factorymethod;

public interface Document {
	
	public DEnum getDocumentType();

}
