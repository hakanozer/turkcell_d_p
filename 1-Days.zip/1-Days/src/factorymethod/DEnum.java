package factorymethod;

public enum DEnum {
	pdf, word;
}
