package abstractfactory;

public interface AbstractFactory {

	public Elma getElma();
	
	public Biber getBiber();
	
	
}
