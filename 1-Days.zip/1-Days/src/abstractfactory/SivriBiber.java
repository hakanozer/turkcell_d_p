package abstractfactory;

public class SivriBiber implements Biber {

	@Override
	public String getType() {
		return "Sivri Biber";
	}

}
