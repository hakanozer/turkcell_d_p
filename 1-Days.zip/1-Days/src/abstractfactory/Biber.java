package abstractfactory;

public interface Biber {

	public String getType();
	
}
