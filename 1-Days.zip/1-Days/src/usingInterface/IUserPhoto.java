package usingInterface;

public interface IUserPhoto {
	
	public String fncUserPhoto( int w, int h );

}
