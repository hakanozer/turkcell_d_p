package factory;

public class A5 extends Araba {

	public A5(final int beygirGucu) {
		super("Audi", "A5", beygirGucu);
	}
	

}
