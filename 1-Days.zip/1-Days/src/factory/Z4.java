package factory;

public class Z4 extends Araba {

	public Z4(final int beygirGucu) {
		super("BMW", "Z4", beygirGucu);
	}

}
