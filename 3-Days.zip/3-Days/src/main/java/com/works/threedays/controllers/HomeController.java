package com.works.threedays.controllers;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.threedays.model.Product;
import com.works.threedays.repostories.ProductRepository;

import props.User;

@Controller
public class HomeController {
	
	Random rd = new Random();
	
	@GetMapping({"", "/"})
	public String home( Model model ) {
		model.addAttribute("rd", rd.nextInt(100));
		return "home";
	}
	
	
	@PostMapping("/login")
	public String login( User us ) {
		System.out.println("Name : " + us.getUserName() + " Pass : " + us.getUserPass());
		return "redirect:";
	}
	

}
