package channel;

public class Customer {

}
