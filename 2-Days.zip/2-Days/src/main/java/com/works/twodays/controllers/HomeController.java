package com.works.twodays.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import builder.Araba;
import builder.SiparisBuilder;
import builder.SiparisManager;
import singleton.Singleton;

@Controller
public class HomeController {
	
	// builder
	SiparisManager manager = new SiparisManager();
	List<Araba> cls = new ArrayList<Araba>();
	
	@GetMapping("")
	public String home( Model model ) {
		//singletonCall();
		model.addAttribute("cls", cls);
		return "home";
	}
	

	public void singletonCall() {
		for (int i = 0; i < 1000; i++) {
			Singleton.instance().write(i);
		}
	}
	
	
	
	@PostMapping("/order")
	public String order( 
			@RequestParam String marka,
			@RequestParam String model,
			@RequestParam String renk,
			@RequestParam int beygirGucu
			) {
		
		Araba ar = manager.createOrder(marka, model, renk, beygirGucu);
		cls.add(ar);
		return "redirect:";
	}
	
	
	
}
