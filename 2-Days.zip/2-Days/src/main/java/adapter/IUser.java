package adapter;

public interface IUser {
	
	public void fncUserName();

}
