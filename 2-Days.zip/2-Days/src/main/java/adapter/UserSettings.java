package adapter;

import java.util.Random;

public class UserSettings {
	
	int a = 10;
	Random rd = new Random();

	public void fncCall() {
		System.out.println("fncCall() call");
	}
	
}
