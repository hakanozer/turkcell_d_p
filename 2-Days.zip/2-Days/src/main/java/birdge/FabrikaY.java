package birdge;

public class FabrikaY {

	public void productDolmaKalem() {
		System.out.println("Fabrika -y : Dolma Kalem");
	}
	
	public void productCizgiliDefater() {
		System.out.println("Fabrika -y : Çizgili Defter");
	}
	
}
