package birdge;

public class FabrikaX {

	public void productTukenmezKalem() {
		System.out.println("Fabrika -X : Tükenmez Kalem");
	}
	
	public void productKareliDefater() {
		System.out.println("Fabrika -X : Kareli Defter");
	}
	
}
