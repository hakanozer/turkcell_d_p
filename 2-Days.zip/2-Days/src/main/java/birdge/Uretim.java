package birdge;

public interface Uretim {

	
	public void productDefter();
	public void productKalem();
	
}
