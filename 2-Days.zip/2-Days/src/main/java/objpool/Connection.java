package objpool;

public class Connection {

	public void write( int number ) {
		System.out.println("Number: " + number);
	}
	
}
